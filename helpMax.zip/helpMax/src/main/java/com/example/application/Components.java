package com.example.application;

import com.vaadin.flow.component.Text;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;

public class Components {



    public VerticalLayout widthLayouts() {
        // Определяем ширину для всех layout'ов
        String layoutWidth = "100%";
        String layoutHeight = "100%";// Можно изменить на любое другое значение
        Text text = new Text("waergunweigiaweugwaeguiwaeguhwaegyubwegbyuwaebbew gbb wbegwewbagbewagewbgyewbaywaegyubaegb");

        // Создаем первый VerticalLayout с красным фоном
        VerticalLayout layout1 = new VerticalLayout();
        layout1.setWidth(layoutWidth);
        layout1.setHeight(layoutHeight);
        layout1.setSpacing(false); // Отключаем пространство между компонентами
        layout1.setMargin(false); // Отключаем внешние отступы
        layout1.add(text);
        layout1.setDefaultHorizontalComponentAlignment(FlexComponent.Alignment.CENTER); // Горизонтальное центрирование
       // layout1.setJustifyContentMode(FlexComponent.JustifyContentMode.CENTER); // Вертикальное центрирование


        return layout1;
    }
}
