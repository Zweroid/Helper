import {applyTheme as _applyTheme} from './theme-mytodo.generated.js';
export const applyTheme = _applyTheme;
